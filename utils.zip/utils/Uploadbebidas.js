import axios from "axios";
import hitImage from '../assets/Jugo Hit.jpg';

const apiKey = 'AIzaSyCtA0Mz6MKRnLuEisaJXUb0_eUOsqw1Uyc';

async function authenticate(mode, email, password) {
    console.log("Iniciando autenticación...");
    const url = `https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${apiKey}`;
    try {
        const response = await axios.post(url, {
            email: email,
            password: password,
            returnSecureToken: true,
        });
        if (response.status === 200) {
            const token = response.data.idToken;
            console.log(token);
            return token;
        } else {
            Alert.alert("Login Failed", "Invalid email or password.");
        }
    } catch (error) {
        Alert.alert("Login Error", "An error occurred. Please try again.");
        console.error(error);
    }
}

export async function login(email, password) {
    console.log("Ejecutando login...");
    return authenticate('signInWithPassword', email, password);
}

// Arreglo de productos con imagen local correctamente referenciada
const products = [
    { id: '1', name: 'Hit', price: 10, description: 'Un delicioso jugo de fruta natural', image: hitImage },
    { id: '2', name: 'Coca-Cola', price: 20, description: 'Refresco popular y refrescante', image: 'https://lavaquita.co/cdn/shop/products/supermercados_la_vaquita_supervaquita_gaseosa_coca_cola_10_oz_zero_bebidas_liquidas_700x700.jpg?v=1620489359' },
    { id: '3', name: 'Tea Hatsu', price: 30, description: 'Té helado refrescante', image: 'https://hatsu.co/wp-content/uploads/2023/04/PRODUCTOS-SITIO-WEB_20.png' },
    { id: '4', name: 'Cafecito', price: 25, description: 'Café aromático y delicioso', image: 'https://carulla.vtexassets.com/arquivos/ids/17473436/Bebida-Cafe-Frappuccino-Coffee-281-ml-91398_a.jpg?v=638613191889800000' },
    { id: '5', name: 'Granizado', price: 30, description: 'Bebida fría y refrescante', image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTwYgRmYE2Fd_SZLmguRbF565s3xdfx4sLuNA&s' },
];

const uploadDataToFirebase = async () => {
    try {
        const response = await axios.put(
            'https://prueba-bebida-default-rtdb.firebaseio.com/products.json',
            products
        );
        console.log('Data subida de manera exitosa:', response.data);
    } catch (error) {
        console.error('Error subiendo la data', error);
    }
};

const getBebidas = async () => {
    try {
        const response = await axios.get('https://prueba-bebida-default-rtdb.firebaseio.com/products.json');
        const productos = [];

        for (const key in response.data) {
            const product = {
                id: key,
                image: response.data[key].image,
                name: response.data[key].name,
                description: response.data[key].description,
                price: response.data[key].price,
            };
            productos.push(product);
        }

        console.log('Productos obtenidos:', productos);
        return productos;
    } catch (error) {
        console.error('Error al obtener los productos', error);
    }
};

export { uploadDataToFirebase, getBebidas };
