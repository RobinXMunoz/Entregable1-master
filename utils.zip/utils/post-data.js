import axios from "axios";

// Función para añadir una compra
export const addCompra = async (product) => {
    try {
        const response = await axios.post(
            'https://prueba-bebida-default-rtdb.firebaseio.com/compras.json',
            product
        );
        console.log('Data subida de manera exitosa:', response.data);
    } catch (error) {
        console.error('Error subiendo la data', error);
    }
};

export default addCompra