// Categories-data.js
import { firestore } from '../Firebase/firebase';

// Función para obtener las categorías
export async function getCategories() {
  try {
    const snapshot = await firestore.collection('categorias').get();
    const categories = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    return categories;
  } catch (error) {
    console.error('Error al obtener categorías:', error);
    throw error;
  }
}
