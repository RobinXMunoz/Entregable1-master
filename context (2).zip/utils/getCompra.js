// utils/getCompra.js
import { firestore } from '../Firebase/firebase'; // Ajusta la ruta según tu configuración

// Función para obtener todas las compras
export async function getCompras() {
    try {
        const comprasSnapshot = await firestore.collection('Compra').get();
        const compras = comprasSnapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data()
        }));
        console.log('Compras obtenidas:', compras);
        return compras;
    } catch (error) {
        console.error('Error al obtener compras:', error);
        return [];
    }
}
