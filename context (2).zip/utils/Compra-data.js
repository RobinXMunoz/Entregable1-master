// utils/Compra-data.js
import { firestore } from '../Firebase/firebase'; // Ajusta la ruta según tu configuración

// Función para agregar una compra
async function addCompra(id,description,image,name, price) {
    try {
        const newCompra = {
            id,
            description,
            image,
            name,
            price,
        };
        // Agregar la compra a la colección "Compra" en Firestore
        const compraRef = await firestore.collection('Compra').add(newCompra);
        console.log('Compra añadida con ID:', compraRef.id);
    } catch (error) {
        console.error('Error al añadir compra:', error);
    }
}

// Ejemplo de uso (puedes comentar o eliminar esto en producción)
//addCompra(3, 15.99, ['producto1', 'producto2'], '2023-10-31', 'factura001');

export default addCompra
