import { firestore } from '../Firebase/firebase';

// Función para agregar una categoría
async function addCategory(nombre) {
  try {
    const newCategory = { nombre: nombre };
    const categoryRef = await firestore.collection('categorias').add(newCategory);
    console.log('Categoría añadida con ID:', categoryRef.id);
  } catch (error) {
    console.error('Error al añadir categoría:', error);
  }
}

// Ejemplo de uso
addCategory("Refrescos");
addCategory("Jugos Naturales");
