async function getCategories() {
    try {
      const querySnapshot = await firestore.collection('categorias').get();
      querySnapshot.forEach((doc) => {
        console.log(`ID: ${doc.id}, Nombre: ${doc.data().nombre}`);
      });
    } catch (error) {
      console.error('Error al obtener categorías:', error);
    }
  }
  
  // Ejemplo de uso
  getCategories();
  