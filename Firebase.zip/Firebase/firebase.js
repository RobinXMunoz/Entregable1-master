// Importa las funciones necesarias de los SDK de Firebase
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore"; // Importa Firestore

// Configuración de Firebase para tu aplicación
const firebaseConfig = {
  apiKey: "AIzaSyCtA0Mz6MKRnLuEisaJXUb0_eUOsqw1Uyc",
  authDomain: "prueba-bebida.firebaseapp.com",
  databaseURL: "https://prueba-bebida-default-rtdb.firebaseio.com",
  projectId: "prueba-bebida",
  storageBucket: "prueba-bebida.appspot.com",
  messagingSenderId: "5927644627",
  appId: "1:5927644627:web:70b8a5fbe3abbcb95e5326"
};

// Inicializa Firebase
const app = initializeApp(firebaseConfig);

// Inicializa Firestore y expórtalo
const firestore = getFirestore(app);
export { firestore };
