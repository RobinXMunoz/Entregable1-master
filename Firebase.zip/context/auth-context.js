import { createContext, useState } from "react";

// Crear el contexto de autenticación con los valores iniciales
export const AuthContext = createContext({
  token: '',
  isLoggedIn: false,
  login: async () => {},
  logout: () => {},
});

function AuthContextProvider({ children }) {
  const [authToken, setAuthToken] = useState(); // Estado para almacenar el token

  // Función para hacer login
  async function login(token) {
    setAuthToken(token);
  }

  // Función para hacer logout
  function logout() {
    setAuthToken(null);
  }

  // Valores del contexto
  const value = {
    token: authToken,
    isLoggedIn: !!authToken, // Convierte el token en un valor booleano
    login: login,
    logout: logout,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

export default AuthContextProvider;
